package model;

import java.util.ArrayList;
import java.util.List;

public class GerenciaTarefas {    
    private static List<Tarefa> tarefas = new ArrayList<Tarefa>();
    
    public GerenciaTarefas() {
        
    }
            
    public static boolean cadastrar(Tarefa tarefa) {
        if(tarefa != null)
            if(!(tarefas.contains(tarefa)))
                return tarefas.add(tarefa);
        return false;
    }
    
    public static List<Tarefa> getTarefas() {
        return tarefas;
    }
    
    public static boolean removerTarefa(Tarefa tarefa){
        if(tarefa != null)
            return tarefas.remove(tarefa);
        return false;
    }
}
