package model;

public interface Prioritizavel {
    
}
