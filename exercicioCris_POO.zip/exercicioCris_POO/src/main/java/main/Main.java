package main;

import br.unifae.engsoft.poo3.gerenciadorDeTarefas.view.CadastroTarefaSimples;

public class Main {
    public static void main(String[] args){
        
        CadastroTarefaSimples  tarefaSimples = new CadastroTarefaSimples();
        tarefaSimples.setVisible(true);
        
    }
}
