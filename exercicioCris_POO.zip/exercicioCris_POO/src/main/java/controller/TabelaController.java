package controller;

import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import model.GerenciaTarefas;
import model.Tarefa;
import model.TarefaComPrazo;

public class TabelaController {

    public void preencherTabela(JTable tabela, List<Tarefa> tarefas) {
        DefaultTableModel modelo = (DefaultTableModel) tabela.getModel();
        modelo.setRowCount(tarefas.size());  // limpa os dados antes de adicionar novos

        // exibe as tarefas na tabela
        for (int i = 0; i < tarefas.size(); i++) {
            Tarefa tarefa = tarefas.get(i);
            if (tarefa != null) {
                // verifica se é tarefa simples ou prazo e depois adiciona
                modelo.setValueAt(tarefa instanceof TarefaComPrazo ? "Com Prazo" : "Simples", i, 0);
                modelo.setValueAt(tarefa.getDescricao(), i, 1);
                modelo.setValueAt(tarefa.getPrioridade(), i, 2);
                modelo.setValueAt(tarefa.getDataCriacao().toString(), i, 3);
                
                if (tarefa instanceof TarefaComPrazo tarefaComPrazo) {
                    modelo.setValueAt(tarefaComPrazo.getPrazo().toString(), i, 4);
                }
            }
        }
    }

    public void excluirLinha(JTable tabela) {
        DefaultTableModel modelo = (DefaultTableModel) tabela.getModel();

        int itemSelecionado = tabela.getSelectedRow();

        // verifica se algo está selecionado antes da exclusão
        if (itemSelecionado != -1) {
            List<Tarefa> listaTarefas = GerenciaTarefas.getTarefas();
            Tarefa tarefaSelecionada = listaTarefas.get(itemSelecionado);
            listaTarefas.remove(tarefaSelecionada);
            modelo.removeRow(itemSelecionado);

            JOptionPane.showMessageDialog(tabela, "Tarefa excluída com sucesso.");

            // verifica se a tabela está vazia
        } else if ((tabela.getRowCount() == 0)) {
            JOptionPane.showMessageDialog(tabela, "Sem tarefas para excluir.");

        } else {
            // se a tabela tiver dados mas nenhuma linha selecionada
            JOptionPane.showMessageDialog(tabela, "Selecione uma linha.");
        }
    }
}
